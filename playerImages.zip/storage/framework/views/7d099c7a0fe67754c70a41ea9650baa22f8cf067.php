
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-2 mt-2">
        <h1 class="col">Players List</h1>
        <div class="col-3">
            <?php $__env->startComponent('components.players.player-import-export'); ?>
            <?php if (isset($__componentOriginal3eb6a692ef9e86c72b8b7a1d22fb88b60cda3415)): ?>
<?php $component = $__componentOriginal3eb6a692ef9e86c72b8b7a1d22fb88b60cda3415; ?>
<?php unset($__componentOriginal3eb6a692ef9e86c72b8b7a1d22fb88b60cda3415); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
        
    </div>
    <?php $__env->startComponent('components.players.player-list',['players' => $players]); ?>
    <?php if (isset($__componentOriginal60d94985a8228bb879a97d9ff1cfcb9d8daf2f01)): ?>
<?php $component = $__componentOriginal60d94985a8228bb879a97d9ff1cfcb9d8daf2f01; ?>
<?php unset($__componentOriginal60d94985a8228bb879a97d9ff1cfcb9d8daf2f01); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ruisa\Github\PlayerQueries\resources\views/pages/players/index.blade.php ENDPATH**/ ?>