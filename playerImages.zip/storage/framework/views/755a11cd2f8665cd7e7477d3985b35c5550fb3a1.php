<div class="container" style="margin-top: 2em">
    <div class="row">
        <div class="col-12">
            <p class="text-center"> Website by Rui using <a href="https://getbootstrap.com">Bootstrap</a>.</p>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\ruisa\Github\PlayerQueries\resources\views/master/footer.blade.php ENDPATH**/ ?>