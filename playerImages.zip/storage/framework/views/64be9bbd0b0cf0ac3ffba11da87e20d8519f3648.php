<form method="POST" action="<?php echo e(url('players/import')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="col-12">
        <h6 class="text-center">Import/Export Spreadsheet</h3>
        <div class="mb-2">
            <div class="custom-file">
                <input 
                    type="file" 
                    class="custom-file-input
                        <?php $__errorArgs = ['import_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="import_file"
                    name="import_file"
                    accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
                <label 
                    class="custom-file-label" 
                    for="import_file">
                    File
                </label>
            </div>
        </div>
        
        <div class="d-flex justify-content-between pl-1 pr-1">
            <a class="btn btn-success flex-fill mr-1" href="<?php echo e(url('players/export')); ?>">
                <i class="bi bi-download"></i>
                Export
            </a>
            <button class="btn btn-primary flex-fill ml-1" type="submit">
                <i class="bi bi-upload"></i>
                Import
            </button>
        </div>
    </div>
</form>

<script>
document.querySelector('#import_file').addEventListener('change', function(e) {
    var fileName = e.target.files[0].name;
    var label = e.target.nextElementSibling;
    label.innerText = fileName;
});
</script><?php /**PATH C:\Users\ruisa\Github\PlayerQueries\resources\views/components/players/player-import-export.blade.php ENDPATH**/ ?>