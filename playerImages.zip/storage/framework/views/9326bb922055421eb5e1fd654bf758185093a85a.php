<form method="POST" action="<?php echo e(url('players/import')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="custom-file row">
        <input 
            type="file" 
            class="custom-file-input" 
            id="import_file"
            name="import_file"
            accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
        <label 
            class="custom-file-label" 
            for="customFile">
            File
        </label>
    </div>
        
    <div class="row">
        <a class="btn btn-success" href="<?php echo e(url('players/export')); ?>">
            <i class="bi bi-download"></i>
            Download
        </a>
        <button class="btn btn-primary" type="submit">
            <i class="bi bi-upload"></i>
            Upload
        </button>
    </div>
</form>

<script>
document.querySelector('#import_file').addEventListener('change', function(e) {
    var fileName = e.target.files[0].name;
    var label = e.target.nextElementSibling;
    label.innerText = fileName;
});
</script><?php /**PATH C:\Users\ruisa\Github\PlayerQueries\resources\views/components/players/player-button-import.blade.php ENDPATH**/ ?>