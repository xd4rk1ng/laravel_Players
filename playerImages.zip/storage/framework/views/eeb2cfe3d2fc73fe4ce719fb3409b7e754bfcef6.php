<form method="" action="<?php echo e(url("players")); ?>" >
    <img class="w-100 img-responsive" src="<?php echo e(asset('storage/' . $player->image_path )); ?>">
    <div class="form-group">
        <label for="name">Name</label>
        <input
            disabled
            type="text"
            id="name"
            name="name"
            autocomplete="name"
            placeholder="Type your name"
            class="form-control"
            value="<?php echo e($player->name); ?>"
            aria-describedby="nameHelp"
        >

    </div>
    <div class="form-group">
        <label for="address">Address</label>
        <input
            disabled
            type="text"
            id="address"
            name="address"
            autocomplete="address"
            placeholder="Type your address"
            class="form-control
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e($player->address); ?>"
            aria-describedby="addressHelp"
        >
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea
            disabled
            id="description"
            name="description"
            rows="5"
            placeholder="Type your description"
            class="form-control"
        ><?php echo e($player->description); ?></textarea>
    </div>
    <div class="form-group">
        <label for="retired">Retired?</label>
        <div class="mb-4">
            <input
                disabled
                type="radio" 
                class="form-check form-check-inline" 
                name="retired" 
                id="retired_yes" 
                value="1" 
                <?php echo e($player->retired ? 'checked' : ''); ?>>
            <label for="retired_yes"> Yes</label>
            <input
                disabled
                type="radio" 
                class="form-check form-check-inline" 
                name="retired" 
                id="retired_no" 
                value="0" 
                <?php echo e(!$player->retired ? 'checked' : ''); ?>>
            <label for="retired_no"> No</label>
        </div>
    </div>
    <button type="back" class="mt-2 mb-5 btn btn-primary">Back</a>
</form><?php /**PATH C:\Users\ruisa\Github\PlayerQueries\resources\views/components/players/player-form-show.blade.php ENDPATH**/ ?>