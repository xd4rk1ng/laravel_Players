<?php if(session('status')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('status')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>
<table class="table table-striped table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Address</th>
      <th scope="col">Retired</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($player->id); ?></th>
            <td><?php echo e($player->name); ?></td>
            <td><?php echo e($player->address); ?></td>
            <td class="text-center">
                <i
                    class="bi  <?php echo e($player->retired ? 'bi-emoji-frown-fill text-danger' : 'bi-emoji-laughing-fill text-primary'); ?>"
                    title="<?php echo e($player->retired ? 'Retired' : 'Active'); ?>"
                ></i>

            </td>
            <td class="row">
                <a class="btn btn-success col" href="<?php echo e(url('players', ['player' => $player])); ?>">Show</a>
                <a class="btn btn-primary col" href="<?php echo e(url('players/' . $player->id . '/edit')); ?>">Edit</a>
                <form action="<?php echo e(url('players/' . $player->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  
                  <button type="submit" class="btn btn-danger col-auto">Delete</a>
                </form>
            </td>
        </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php /**PATH C:\Users\ruisa\Github\PlayerQueries\resources\views/components/players/player-list.blade.php ENDPATH**/ ?>